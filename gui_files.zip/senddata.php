<?php
	echo("1");
	$username = $_POST["username"];
	$password = $_POST["password"];
	
	$result = shell_exec("python_recv.py" .$username .$password);
	echo ($result);
	
?>