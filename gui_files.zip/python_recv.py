import sys

vUsername = sys.argv[1]
vPassword = sys.argv[2]

return(vUsername, vPassword)
